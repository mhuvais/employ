
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-themecolor">Import CSV file</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <a href="<?php echo base_url();?>assets/downloads/sample.csv" download
                            class="btn waves-effect waves-light btn-success pull-right hidden-sm-down">Download sample
                            </a>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
           
                    <!-- Column -->
                    <div class="col-lg-8 col-xlg-9">
                        <div class="card">
                            <div class="card-body">
  
    <?php if(!empty($error)){ ?>
    <div class="col-xs-12">
        <div class="alert alert-danger"><?php echo $error; ?></div>
    </div>
    <?php } ?>
                                <form class="form-horizontal form-material mx-2" enctype="multipart/form-data" method="POST" action="<?php echo base_url();?>Employ/upload_csv">
                                <div class="form-group">
                                        <label class="col-md-12">Select csv file</label>
                                        <div class="col-md-12">
                                            <input type="file" required name="file"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>   
                                <label class="text-danger">Please specify each column header</label>
                                <div class="form-group">
                                        <label class="col-md-12">Name</label>
                                        <div class="col-md-12">
                                            <input type="text" required name="name" 
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Employee Code</label>
                                        <div class="col-md-12">
                                            <input type="text" required  name="code"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Date Of Birth</label>
                                        <div class="col-md-12">
                                            <input type="text" required  name="dob"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Date Of Joining</label>
                                        <div class="col-md-12">
                                            <input type="text" required  name="jod"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="example-email" class="col-md-12">Email</label>
                                        <div class="col-md-12">
                                            <input type="text" required name="email" 
                                                class="form-control form-control-line" name="example-email"
                                                id="example-email">
                                        </div>
                                    </div>
                                  
                                    <div class="form-group">
                                        <label class="col-md-12">Phone No</label>
                                        <div class="col-md-12">
                                            <input type="text" name="phone" required 
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-12">Department</label>
                                        <div class="col-md-12">
                                            <input type="text" required  name="department"
                                                class="form-control form-control-line">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="col-sm-12">
                                            <button type="submit" class="btn btn-success">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- ============================================================== -->
                <!-- End PAge Content -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
         