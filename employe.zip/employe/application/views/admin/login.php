<!DOCTYPE html> 
<html> 
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> Login Page </title>
<link href="<?php echo base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">

<style> 
Body {
  font-family: Calibri, Helvetica, sans-serif;
}
button { 
       background-color: #4CAF50; 
       width: 100%;
        color: orange; 
        padding: 15px; 
        margin: 10px 0px; 
        border: none; 
        cursor: pointer; 
         } 
 form { 
        border: 3px solid #f1f1f1; 
    } 
 input[type=text], input[type=password] { 
        width: 100%; 
        margin: 8px 0;
        padding: 12px 20px; 
        display: inline-block; 
        border: 2px solid green; 
        box-sizing: border-box; 
    }
 button:hover { 
        opacity: 0.7; 
    } 
  .cancelbtn { 
        width: auto; 
        padding: 10px 18px;
        margin: 10px 5px;
    } 
      
   
 .container { 
     margin: 10%;
        padding: 10%; 
        background-color: lightblue;
    } 
</style> 
</head>  
<body>  
    <center> <h1>Login Form </h1> </center> 
    <form>
        <div class="container mt-40"> 
            <label>Username : </label> 
            <input type="text" placeholder="Enter Username" id="user" name="username" required>
            <label>Password : </label> 
            <input type="password" placeholder="Enter Password" id="pass" name="password" required>
            <label class="text-danger d-none" id="err_code">Check Credentials</label>
            <button id="login" type="button">Login</button> 
     
        </div> 
    </form>   

    <script src="<?php echo base_url();?>assets/plugins/jquery/jquery.min.js"></script>
     <script>
         $("#login").click(function(){
           user=$("#user").val();
           pass=$("#pass").val();
           if(user!="" && pass!="")
           {
            $.ajax({
	                           	method: 'POST',
	                           	url: '<?php echo base_url(); ?>Authentication/check_login',
	                           	data: {user:user,pass:pass},
	                           
	                           	dataType: 'JSON',
	                           	success: function (data) {
	                           		if(data==0)
                                       {
                                        $( "#err_code" ).removeClass("d-none");
                                          
                                       }
                                       else{
                                         window.location="<?php echo base_url();?>Employ";
                                       }
	                           	},
	                           	error: function (data) {
	                           	}

	                          });
           }
           else{
            $( "#err_code" ).removeClass("d-none");

           }
         });
     </script>
    <script src="<?php echo base_url();?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>   
</html>

 
