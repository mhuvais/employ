
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper  -->
        <!-- ============================================================== -->
        <div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-5 align-self-center">
                        <h3 class="text-themecolor">Dashboard</h3>
                    </div>
                    <div class="col-md-7 align-self-center">
                        <a href="<?php echo base_url();?>Employ/add_employee"
                            class="btn waves-effect waves-light btn-danger pull-right hidden-sm-down"> Add Employees</a>
                    </div>
                </div>
    
                <!-- ============================================================== -->
                <!-- Projects of the month -->
                <!-- ============================================================== -->
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="d-flex">
                                    <div>
                                        <h4 class="card-title"><span class="lstick"></span>List of employs</h4>
                                    </div>
                                </div>
                                <div class="table-responsive mt-3">
                                    <table class="table vm no-th-brd no-wrap pro-of-month">
                                        <thead>
                                            <tr>
                                                <th>SL.No</th>
                                                <th>Employee Code</th>
                                                <th>Employee Name</th>
                                                <th>Department</th>
                                                <th>Age</th>
                                                <th>Experience</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $n=1;
                                            foreach($employs as $emp)
                                            {
                                                $jod=new DateTime($emp->employ_jod);
                                                $today=new DateTime(date('Y-m-d'));
                                                $diff=$jod->diff($today);
                                                ?>
                                            
                                            <tr>
                                                <td><?php echo $n;?></td>
                                                <td><?php echo $emp->employ_code;?></td>
                                                <td><?php echo $emp->employ_name;?></td>
                                                <td><?php echo $emp->employ_department;?></td>
                                                <td><?php echo date_diff(date_create($emp->employ_dob), date_create('today'))->y;?></td>
                                                <td><?php echo $diff->format('%y years %m months and %d days');?></td>
                                                <td><a href="<?php echo base_url();?>Employ/view_employee?id=<?php echo $emp->employ_id;?>" class="btn btn-warning">Edit</a></td>

                                            </tr>
                                            <?php
                                             $n++; }
                                           
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
            
                </div>

            </div>
