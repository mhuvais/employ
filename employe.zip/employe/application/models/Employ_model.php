<?php

class Employ_model extends CI_Model {
    public function check_login($user,$pass)
    {
        $this->db->where('username',$user);
        $this->db->where('password',$pass);
        return $this->db->get('users')->num_rows();

    }
    public function get_all_employs()
    {
        return $this->db->get('employ_data')->result();
    }
    public function add_employ($data)
    {
        return $this->db->insert('employ_data',$data);
    }
    public function get_employ($id)
    {
        $this->db->where('employ_id',$id);
        return $this->db->get('employ_data')->row();
    }
    public function update_employ($id,$data)
    {
        $this->db->where('employ_id',$id);
        return $this->db->update('employ_data',$data);
    }
    public function delete_employ($id)
    {
        $this->db->where('employ_id',$id);
        return $this->db->delete('employ_data');
    }
    public function check_mail($email)
    {
        $this->db->where('employ_email',$email);
        return $this->db->get('employ_data')->num_rows();
    }
    public function check_phone($email)
    {
        $this->db->where('employ_phone',$email);
        return $this->db->get('employ_data')->num_rows();
    }
    public function check_code($email)
    {
        $this->db->where('employ_code',$email);
        return $this->db->get('employ_data')->num_rows();
    }
    }
?>