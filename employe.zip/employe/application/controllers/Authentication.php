<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Authentication extends CI_Controller {
    public function index()
    {
        $this->load->view('admin/login');
    }
    public function check_login()
    {
        $user=$this->input->post('user');
        $pass=$this->input->post('pass');

        $check=$this->Employ_model->check_login($user,$pass);
        if($check)
        {
            $this->session->set_userdata('login','login');
        }
        echo json_encode($check);
    }
    public function logout()
    {
        $this->session->unset_userdata('login');
        redirect('');
    }
}
