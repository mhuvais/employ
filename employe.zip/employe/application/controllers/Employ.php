<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Employ extends CI_Controller {

    public function __construct()
	{
		parent::__construct();
        $this->check_log();
	}
    public function check_log()
    {
        if(!$this->session->userdata('login')){
            redirect('Authentication');
        }
    }
	public function index()
	{
        $data['employs']=$this->Employ_model->get_all_employs();
		$this->load->view('admin/header');
		$this->load->view('admin/index',$data);
		$this->load->view('admin/footer');
	}
    public function add_employee()
    {
        $this->load->view('admin/header');
		$this->load->view('admin/register');
		$this->load->view('admin/footer');
    }
    public function create_employ()
    {
        $data=array(
            'employ_name'=>trim($this->input->post('name')),
            'employ_code'=>trim($this->input->post('code')),
            'employ_department'=>trim($this->input->post(('department'))),
            'employ_dob'=>trim($this->input->post('dob')),
            'employ_jod'=>trim($this->input->post('jod')),
            'employ_phone'=>trim($this->input->post('phone')),
            'employ_email'=>trim($this->input->post('email'))
        );
        $result=$this->Employ_model->add_employ($data);

        if($result)
        {
            redirect('');
        }
        else{
            
        }
    }
    public function view_employee()
    {
        $id=$this->input->get('id');
        $data['employ']=$this->Employ_model->get_employ($id);
        $this->load->view('admin/header');
		$this->load->view('admin/edit_employ',$data);
		$this->load->view('admin/footer');
    }
    public function edit_employ($id)
    {
        $data=array(
            'employ_name'=>trim($this->input->post('name')),
            'employ_code'=>trim($this->input->post('code')),
            'employ_department'=>trim($this->input->post(('department'))),
            'employ_dob'=>trim($this->input->post('dob')),
            'employ_jod'=>trim($this->input->post('jod')),
            'employ_phone'=>trim($this->input->post('phone')),
            'employ_email'=>trim($this->input->post('email'))
        );
        $result=$this->Employ_model->update_employ($id,$data);
        redirect('');

    }
    public function remove_employee()
    {
        $id=$this->input->get('id');
        $result=$this->Employ_model->delete_employ($id);
        redirect('');
    }
    public function add_csv()
    {
        if($this->session->userdata('err_message')){
            $data['error'] = $this->session->userdata('err_message');
            $this->session->unset_userdata('err_message');
        }
        else{
            $data['error']="";
        }
        $this->load->view('admin/header');
		$this->load->view('admin/csv_upload',$data);
		$this->load->view('admin/footer');
    }
    public function upload_csv()
    {
        if($this->session->userdata('err_message')){
            $data['error'] = $this->session->userdata('err_message');
            $this->session->unset_userdata('err_message');
        }
           //columns
           $employ_name=trim($this->input->post('name'));
            $employ_code=trim($this->input->post('code'));
            $employ_department=trim($this->input->post('department'));
            $employ_dob=trim($this->input->post('dob'));
            $employ_jod=trim($this->input->post('jod'));
            $employ_phone=trim($this->input->post('phone'));
            $employ_email=trim($this->input->post('email'));

                    // Parse data from CSV file
                    $csvData = $this->csvreader->parse_csv($_FILES['file']['tmp_name']);
                    $row_count=count($csvData);
                    // Insert/update CSV data into database
                   $row_count=0;
                        foreach($csvData as $row){ 
                            if($row_count <=20)
                            {
                            $row_count++;
                            $email=$row[$employ_email];
                            $phone=$row[$employ_phone];
                            $code=$row[$employ_code];

                            $check_mail=$this->Employ_model->check_mail($email);
                            $check_phone=$this->Employ_model->check_phone($phone);
                            $check_code=$this->Employ_model->check_code($code);
                            if($check_mail==0 && $check_phone==0 && $check_code==0){
                            $data = array(
                                'employ_name'=>$row[$employ_name],
                                'employ_code'=>$row[$employ_code],
                                'employ_department'=>$row[$employ_department],
                                'employ_dob'=>$row[$employ_dob],
                                'employ_jod'=>$row[$employ_jod],
                                'employ_phone'=>$row[$employ_phone],
                                'employ_email'=>$row[$employ_email]
                            );
                            $this->Employ_model->add_employ($data);

                        }
                        else{
                            $this->session->set_userdata('err_message','Error on file upload, duplication error');
                        }
                        }
                            
                        }
                        redirect('Employ/add_csv');
    }
        //ajax validation

    public function check_code()
    {
        $code=$this->input->post('code');
        $check_code=$this->Employ_model->check_code($code);
        echo json_encode($check_code);

    }  
    public function check_mail()
    {
        $mail=$this->input->post('mail');
        $check_mail=$this->Employ_model->check_mail($mail);
        echo json_encode($check_mail);

    }  
    public function check_phone()
    {
        $phone=$this->input->post('phone');
        $check_phone=$this->Employ_model->check_code($phone);
        echo json_encode($check_phone);

    }    
}
